---
name: Ethereal Connection
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#debec8'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#a68992'
  outline-variant: '#574048'
  surface-tint: '#ffb0cd'
  primary: '#ffb0cd'
  on-primary: '#640039'
  primary-container: '#f751a1'
  on-primary-container: '#570032'
  inverse-primary: '#b4136d'
  secondary: '#d0bcff'
  on-secondary: '#3c0091'
  secondary-container: '#571bc1'
  on-secondary-container: '#c4abff'
  tertiary: '#ffb4ac'
  on-tertiary: '#690007'
  tertiary-container: '#f55e55'
  on-tertiary-container: '#5c0005'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffd9e4'
  primary-fixed-dim: '#ffb0cd'
  on-primary-fixed: '#3e0022'
  on-primary-fixed-variant: '#8c0053'
  secondary-fixed: '#e9ddff'
  secondary-fixed-dim: '#d0bcff'
  on-secondary-fixed: '#23005c'
  on-secondary-fixed-variant: '#5516be'
  tertiary-fixed: '#ffdad6'
  tertiary-fixed-dim: '#ffb4ac'
  on-tertiary-fixed: '#410002'
  on-tertiary-fixed-variant: '#8e1214'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  display-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 64px
    fontWeight: '700'
    lineHeight: 72px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Be Vietnam Pro
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Be Vietnam Pro
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-md-mobile:
    fontFamily: Be Vietnam Pro
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  body-md:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-max: 1200px
  gutter: 24px
  margin-mobile: 20px
  section-gap: 120px
  element-gap: 16px
---

## Brand & Style

The design system is centered on a **Premium Glassmorphic** aesthetic, tailored specifically for high-end dating experiences. The brand personality is sophisticated, intimate, and modern, aiming to evoke a sense of exclusivity and romantic possibility. 

The visual language utilizes deep, multi-layered gradients and translucent surfaces to create a sense of three-dimensional space. By blending high-fidelity glass effects with bold, romantic colors, the UI achieves a balance between technological polish and emotional warmth. The target audience expects a frictionless, high-end service where the interface feels as curated as the matches themselves.

## Colors

This design system utilizes a dark-mode foundation to allow romantic gradients to resonate with maximum vibrance. 

- **Primary (Pink):** Used for primary actions, active states, and highlighting key romantic value propositions.
- **Secondary (Purple):** Employed for accents, secondary buttons, and as a transitional hue in background gradients.
- **Tertiary (Dark Red):** Reserved for deep background layers and subtle shadows to add weight and "mood" to the canvas.
- **Glass Surface:** A translucent white (`rgba(255, 255, 255, 0.08)`) is used for component containers to create the signature frosted effect against the dark background.
- **Text:** Pure white (#FFFFFF) is the standard for high-readability, with reduced opacity whites used for secondary metadata.

## Typography

The typography utilizes **Be Vietnam Pro** to deliver a contemporary and approachable feel while maintaining the clean lines required for a premium product. 

For display and headlines, use a tighter letter-spacing to create a "locked-in" editorial look. Body text should maintain standard tracking to ensure legibility against shimmering glass backgrounds. Use "Label" styles for uppercase category headers or small calls-to-action within cards to maintain a structured hierarchy.

## Layout & Spacing

The layout follows a **fluid-to-fixed** model. On desktop, content is contained within a 1200px central track using a 12-column grid. On mobile, the layout shifts to a single column with generous 20px side margins.

Spacial rhythm is intentionally loose to evoke a sense of luxury and "breathing room." Section vertical gaps should be significant (120px+) to ensure the landing page feels like a journey rather than a dense information dump. Use symmetrical padding within glass containers to emphasize their geometric perfection.

## Elevation & Depth

Visual hierarchy in the design system is achieved through **Backdrop Blurs** and **Tonal Depth** rather than traditional opaque stacking.

- **Level 1 (Background):** Deep mesh gradients mixing #991B1B and #0F172A.
- **Level 2 (Containers):** Glassmorphic panels with a 20px-40px `backdrop-filter: blur()`. These panels must have a 1px semi-transparent white border (top and left especially) to simulate a "light catch" on the edge of the glass.
- **Level 3 (Interactive):** Floating elements and buttons use soft, expansive shadows with a color tint derived from the primary pink (#EC4899) at very low opacity (15%). This creates a "glow" rather than a shadow.

## Shapes

The shape language is defined by **Extra Large (2xl)** radii. All primary containers, image cards, and input fields must use a consistent 1.5rem (24px) corner radius. This high level of roundedness softens the tech-heavy glass aesthetic, making the interface feel more organic, inviting, and "human-centric"—essential for a dating platform.

## Components

### Buttons
Primary buttons use a linear gradient from #EC4899 to #8B5CF6, angled at 135 degrees. They feature a subtle white inner-glow on hover. Secondary buttons are "Ghost Glass"—transparent with a 1px border and a subtle hover blur increase.

### Cards
Cards are the hero of the design system. They must use the glassmorphic treatment: a semi-transparent background, high-intensity backdrop blur, and rounded corners. Images inside cards should have a subtle darkening overlay at the bottom to ensure white text overlay remains legible.

### Form Inputs
Inputs should appear as "sunken" glass. Use a slightly darker translucent background than the card surface to create a sense of an inset field. The focus state should illuminate the 1px border with the primary pink color.

### Chips & Badges
Small, pill-shaped elements used for "Interests" or "Status." These should use high-saturation gradients with white text at a small, bold scale to pop against the glass surfaces.